# online-shopping-with-advanced-admin-page
Updated version


online shopping system with both admin and user layouts.

admin login details  Email=admin@gmail.com and Password=123456789.
